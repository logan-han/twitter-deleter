window.YTD.tweet.part0 = [ {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "SSun",
        "screen_name" : "icehit3",
        "indices" : [ "0", "8" ],
        "id_str" : "35473267",
        "id" : "35473267"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "83" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "2201539033",
    "id_str" : "2201660788",
    "in_reply_to_user_id" : "35473267",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "2201660788",
    "in_reply_to_status_id" : "2201539033",
    "created_at" : "Wed Jun 17 03:35:29 +0000 2009",
    "favorited" : false,
    "full_text" : "blah",
    "lang" : "ko",
    "in_reply_to_screen_name" : "icehit3",
    "in_reply_to_user_id_str" : "35473267"
  }
}]
